console.log('Popup opened');
